Have a browser Web Browser (Chrome, Firefox, etc.)
Install VSCode
Download and install XAMPP from apachefriends.org
Open XAMPP Control Panel
Start the following services:
- Apache
- MySQL
Open your browser and visit: http://localhost/phpmyadmin for database
Visit site with localhost (http://localhost/Rar-Rent_a_Car-1/index.php)
