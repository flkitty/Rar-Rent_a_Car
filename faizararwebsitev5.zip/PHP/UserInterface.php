<?php
interface UserInterface {
    public function getUserId();
    public function getFirstName();
    public function getLastName();
    public function getEmail();
}
?>